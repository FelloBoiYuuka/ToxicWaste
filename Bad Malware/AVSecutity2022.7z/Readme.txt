Virus name: AV Secutity 2022
Virus type: FakeAV
Damage Rate: Destructive
Made in: VB6, c, c++
Works on: WinXP, Win7
Do not run on Real PC, use a VM